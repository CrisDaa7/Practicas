/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista.listas.tablas;

import controlador.listaEnlazada.ListaEnlazada;
import javax.swing.table.AbstractTableModel;
import modeloListas.Vendedor;

/**
 *
 * @author cristian
 */
public class VendedorTablaModelo extends AbstractTableModel {

    private ListaEnlazada<Vendedor> vendedores;

    public VendedorTablaModelo() {
        vendedores = new ListaEnlazada<>();
    }

    public ListaEnlazada<Vendedor> getVendedores() {
        return vendedores;
    }

    public void setVendedores(ListaEnlazada<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    @Override
    public int getRowCount() {
        return vendedores.getSize();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int fila, int columna) {

        try {
            // Llanta l=llantas.getElemento(fila);
            Vendedor l = vendedores.get(fila);

            switch (columna) {
                case 0:
                    return l == null ? "" : l.getId();
                case 1:
                    return l == null ? "" : l.getNombre();
                case 2:
                    return l == null ? "" : l.getApellido();
                case 3:
                    return l == null ? "" : l.getCedula();
                case 4:
                    return l == null ? "" : l.getRuc();
            }
        } catch (Exception e) {
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id";
            case 1:
                return "Nombre";
            case 2:
                return "Apellido";
            case 3:
                return "Cedula";
            case 4:
                return "Ruc";
        }

        return null;
    }
}
