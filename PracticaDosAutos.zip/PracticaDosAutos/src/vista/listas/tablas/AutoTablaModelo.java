/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista.listas.tablas;

import controlador.listaEnlazada.ListaEnlazada;
import javax.swing.table.AbstractTableModel;
import modeloListas.Auto;

/**
 *
 * @author cristian
 */
public class AutoTablaModelo extends AbstractTableModel {

    private ListaEnlazada<Auto> autos;

    public AutoTablaModelo() {
        autos = new ListaEnlazada<>();
    }

    public ListaEnlazada<Auto> getAutos() {
        return autos;
    }

    public void setAutos(ListaEnlazada<Auto> llantas) {
        this.autos = llantas;
    }

    @Override
    public int getRowCount() {
        return autos.getSize();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int fila, int columna) {

        try {
            // Llanta l=llantas.getElemento(fila);
            Auto l = autos.get(fila);

            switch (columna) {
                case 0:
                    return l == null ? "" : l.getId_vendedor();
                case 1:
                    return l == null ? "" : l.getMarca();
                case 2:
                    return l == null ? "" : l.getPrecio();
                case 3:
                    return l == null ? "" : l.getColor();
            }
        } catch (Exception e) {
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Vendedor";
            case 1:
                return "Marca";
            case 2:
                return "Precio";
            case 3:
                return "Color";
        }

        return null;
    }
}
