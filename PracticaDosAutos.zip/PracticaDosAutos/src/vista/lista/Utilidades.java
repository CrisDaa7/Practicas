/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista.lista;

import controlador.listaEnlazada.ListaEnlazada;
import controlador.listaEnlazada.exepcion.VacioExcepcion;
import controladorListas.ControlarVendedor;
import javax.swing.JComboBox;
import modeloListas.Vendedor;

/**
 *
 * @author cristian
 */
public class Utilidades {
  public static void cargarVendedor(JComboBox cbxVendedor) throws VacioExcepcion {
    ControlarVendedor cm = new ControlarVendedor();
    cbxVendedor.removeAllItems();
    
  //ListaEnlazada<Marca> marcas=new ListaEnlazada<>();
    for (int i = 0; i < cm.getVendedores().getSize(); i++) {
        try {
            cbxVendedor.addItem(cm.getVendedores().getElemento(i));
        } catch (Exception e) {
        }
        
    }
}
 public static void cargarVendedorL(JComboBox cbxVendedor) throws VacioExcepcion {
    controladorListas.ControlarVendedor cm = new controladorListas.ControlarVendedor();
    cbxVendedor.removeAllItems();
    
  //ListaEnlazada<Marca> marcas=new ListaEnlazada<>();
    for (int i = 0; i < cm.getVendedores().getSize(); i++) {
        try {
            cbxVendedor.addItem(cm.getVendedores().get(i));
        } catch (Exception e) {
        }
        
    }
}
      
      
      public static Vendedor getComboVendedorL(JComboBox cbx){
          return (Vendedor)cbx.getSelectedItem();
      }
}
