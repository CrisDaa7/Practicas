/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.listaEnlazada;

import controlador.listaEnlazada.exepcion.PositionException;
import controlador.listaEnlazada.exepcion.VacioExcepcion;

/**
 *
 * @author cristian
 */
public class ListaEnlazada<E> {

    private Nodo<E> cabecera;
    private Nodo<E> ultimo;
    private Integer size;

    public ListaEnlazada() {
        cabecera = null;
        ultimo = null;
        size = 0;
    }

    public Boolean isEmpty() {
        return cabecera == null;
    }

    public void insertarInicio(E info) {
        if (isEmpty()) {
            Nodo<E> aux = new Nodo<>(info, null);
            cabecera = aux;
            ultimo = aux;
        } else {
            Nodo<E> cabeceraVieja = cabecera;
            Nodo<E> aux = new Nodo<>(info, cabeceraVieja);
            cabecera = aux;
        }
        size++;
    }

    public void insertarFinal(E info) {
        if (isEmpty()) {
            insertarInicio(info);
        } else {
            Nodo<E> aux = new Nodo<>(info, null);
            ultimo.setSig(aux);
            ultimo = aux;
            size++;
        }
        
    }

    public void insertarPosicion(E info) {
        insertarFinal(info);
    }

    public void insertarPosicion(E info, Integer pos) throws VacioExcepcion {
        if (pos == 0) {
            insertarInicio(info);
        } else if (pos.intValue() == size.intValue()) {
            insertarFinal(info);
        } else {
            Nodo<E> buscarAnterior = getNodo(pos - 1);
            Nodo<E> buscar = getNodo(pos);
            Nodo<E> aux = new Nodo<>(info, buscar);
            buscarAnterior.setSig(aux);
            size++;
        }
    }
    
    public E getPrimero() throws VacioExcepcion{
        if(isEmpty()){
            throw new VacioExcepcion("Lista Vacia");
        }else{
            return cabecera.getInfo();
        }
    }
    
      public E getUltimo() throws VacioExcepcion{
        if(isEmpty()){
            throw new VacioExcepcion("Lista Vacia");
        }else{
            return ultimo.getInfo();
        }
    }

      public E get(Integer index) throws VacioExcepcion{
          if(isEmpty()){
              throw new VacioExcepcion("Lista Vacia");
          }else if(index.intValue()<0||index.intValue()>=size){
              throw new IndexOutOfBoundsException("Fuera de rango");
          }else if(index.intValue()==0){
              return getPrimero();
          }else if(index.intValue()==(size-1)){
              return getUltimo();
          }else{
              Nodo<E> buscar=getNodo(index);
              return buscar.getInfo();
          }
      }
    private Nodo<E> getNodo(Integer pos) throws VacioExcepcion {
        if (isEmpty()) {
            throw new VacioExcepcion();
        } else if (pos < 0 || pos > +size) {
            throw new IndexOutOfBoundsException("Erro,esta fuera de los limites de la lista");
        } else if (pos == 0) {
            return cabecera;
        } else if (pos == (size - 1)) {
            return ultimo;
        } else {
            Nodo<E> buscar = cabecera;
            Integer cont = 0;
            while (cont < pos) {
                cont++;
                buscar = buscar.getSig();
            }
            return buscar;
        }
    }
    
 public String imprimir() {
    StringBuilder sb = new StringBuilder();
    if (isEmpty()) {
        sb.append("Lista vacía");
    } else {
        Nodo<E> aux = cabecera;
        while (aux != null) {
            sb.append(aux.toString());
            sb.append("\n"); // Agrega un salto de línea entre nodos
            aux = aux.getSig();
        }
    }
    return sb.toString();
}




    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

   
        
    public E getElemento(int i) throws VacioExcepcion {
    Nodo<E> nodo = getNodo(i);
    return nodo.getInfo();
}

       //Hacer Eliminar
    public E deleteFirst() throws VacioExcepcion {
        if (isEmpty()) {
            throw new VacioExcepcion("List Empty");
        } else {

            E element = cabecera.getInfo();
            Nodo<E> aux = cabecera.getSig();
            cabecera = aux;
            if (size.intValue() == 1) {
                ultimo = null;
            }
            size--;
            return element;
        }
    }

    public E deleteLast() throws VacioExcepcion {
        if (isEmpty()) {
            throw new VacioExcepcion("List Empty");
        } else {

            E element = ultimo.getInfo();
            Nodo<E> aux = getNodo(size - 2);
            if (aux == null) {
                ultimo = null;
                if (size == 2) {
                    ultimo = cabecera;
                } else {
                    cabecera = null;
                }
            } else {
                ultimo = null;
                ultimo = aux;
                ultimo.setSig(null);
            }

            size--;
            return element;
        }
    }
    
        public void clear() {
        cabecera = null;
        size = 0;
        ultimo = null;
    }

    public E delete(Integer pos) throws VacioExcepcion {
        if (isEmpty()) {
            throw new VacioExcepcion("Lista Esta Vacia ");
        } else if (pos < 0 || pos > size) {
            throw new IndexOutOfBoundsException("Error esta fuera de los limites de la lista");
        } else if (pos == 0) {
            return deleteFirst();
        } else if (pos == (size - 1)) {
            return deleteLast();
        } else {
            Nodo<E> preview = getNodo(pos -1);
            Nodo<E> actually = getNodo(pos);
            E element = preview.getInfo();
            
            Nodo<E> next = actually.getSig();
            actually = null;
            preview.setSig(next);
            size--;
            return  element;
        }
        

    }

//    public static void main(String[] args) {
//        ListaEnlazada<Integer> numerics = new ListaEnlazada<>();
//        for (int i = 0; i < 10; i++) {
//            Integer aux = (int) (Math.random() * 1000);
//            numerics.insertarInicio(i);
//        }
//
//        System.out.println("Lista original:");
//        System.out.println(numerics.imprimir());
//        System.out.println("Tamaño de la lista: " + numerics.getSize());
//
//        try {
//            // Supongamos que queremos actualizar el elemento en la posición 3 con un nuevo valor
//            int posToUpdate = 3;
//            int newValue = 999;
//
//            System.out.println("---------------------------------------------");
//            System.out.println("Actualizando elemento en la posición " + posToUpdate + " con el valor " + newValue);
//            System.out.println("Lista actualizada:");
//            System.out.println(numerics.imprimir());
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }
    
      public void update(E dato, Integer pos) throws VacioExcepcion, PositionException {
        if (isEmpty()) {
            throw new VacioExcepcion("Lista Vacia");
        } else {

            if (pos >= 0 && pos < getSize()) {
                if (pos == 0) {
                    cabecera.setInfo(dato);
                } else {
                    Nodo<E> aux = cabecera;
                    for (int i = 0; i < pos; i++) {
                        aux = aux.getSig();
                    }
                    aux.setInfo(dato);
                }

            } else {
                throw new PositionException("Posición fuera de rango");
            }
        }
    }
        public void Update2(E data, Integer pos) throws VacioExcepcion {
        if (isEmpty()) {
            throw new VacioExcepcion("Lista Esta Vacia ");
        } else if (pos < 0 || pos > size) {
            throw new IndexOutOfBoundsException("Error esta fuera de los limites de la lista");
        } else if (pos == 0) {
            cabecera.setInfo(data);
        } else if (pos == (size - 1)) {
            ultimo.setInfo(data);
        } else {
            Nodo<E> search = cabecera;
            Integer cont = 0;
            while (cont < pos) {
                cont++;
                search = search.getSig();
            }
            search.setInfo(data);
        }
    }

        
}
        
        
//         public static void main(String[] args) {
//        ListaEnlazada<Integer> n=new ListaEnlazada<>();
//             for (int i = 0; i < 10; i++) {
//                 Integer aux=(int)(Math.random()*1000);
//                 n.insertarPosicion(aux);
//             }
//             System.out.println(n.imprimir());
//             System.out.println("Tamano de lista "+ n.getSize());
//             try {
//               //  n.insertarInicio(1,10);
//                 n.insertarPosicion(1, 5);
//                 System.out.println("-------------------");
//                 System.out.println(n.imprimir());
//                 System.out.println(n.getNodo(9).getInfo().toString());
//                 System.out.println("Tamano de lista "+ n.getSize());
//             } catch (Exception e) {
//                 System.out.println(e.getMessage());
//             }
//    }

