/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controladorListas.dao;

import controlador.listaEnlazada.ListaEnlazada;
import java.io.IOException;

/**
 *
 * @author cristian
 */
public interface InterfazDao<T> {
    
    public Boolean guardar(T info);
    public Boolean modificar(T info,Integer index);
    public ListaEnlazada<T> listar();
    public T buscar(Integer id);
//
//    public void guardar(T obj) throws IOException;
//
//    public void modificar(T obj, Integer pos) throws IOException;
//
//    public ListaEnlazada<T> listar() throws IOException;
//
//    public T get(Integer id);
}
