/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladorListas.dao;

import com.thoughtworks.xstream.XStream;
import controlador.listaEnlazada.ListaEnlazada;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;


/**
 *
 * @author cristian
 */
public class AdaptadorDao<T> implements InterfazDao {

    private XStream xstream;
    private Class<T> clazz;
    private String URL;

   public AdaptadorDao(Class<T> clazz) {
    xstream = Conexion.getXstream();
    this.clazz = clazz; 
    URL = Conexion.getURL() + this.clazz.getSimpleName() + ".json";
}


    @Override
    public Boolean guardar(Object info) {
          ListaEnlazada<T> lista = listar();
        lista.insertarPosicion((T) info);
        try {
            this.xstream.toXML(lista, new FileOutputStream(URL));
        } catch (FileNotFoundException ex) {
            return false;
        }
        return true;
    }

    @Override
    public Boolean modificar(Object data, Integer index) {
   ListaEnlazada<T> list = listar();
        try {
            //list.update(data, index);
            
            list.Update2((T) data, index);
//            xstream.alias(list.getClass().getName(), LinkedList.class);
            xstream.toXML(list, new FileOutputStream(URL));
        } catch (Exception ex) {
            return false;
        }
        return true;    }

    @Override
    public ListaEnlazada<T> listar() {
        //save an linkedList
        ListaEnlazada<T> lista = new ListaEnlazada<>();
        try {
            lista = (ListaEnlazada<T>) xstream.fromXML(new FileReader(URL));
        } catch (FileNotFoundException ex) {
        }
        return lista;
    }

    @Override
    public Object buscar(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Integer generarId(){
        return listar().getSize()+1;
        
    }
}
