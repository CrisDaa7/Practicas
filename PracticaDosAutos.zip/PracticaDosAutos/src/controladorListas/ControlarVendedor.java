/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladorListas;

import controlador.listaEnlazada.ListaEnlazada;
import controlador.listaEnlazada.exepcion.PositionException;
import controlador.listaEnlazada.exepcion.VacioExcepcion;
import controladorListas.dao.AdaptadorDao;
import java.io.IOException;
import modeloListas.Vendedor;

/**
 *
 * @author cristian
 */
public class ControlarVendedor extends AdaptadorDao<Vendedor> {

    private ListaEnlazada<Vendedor> vendedores = new ListaEnlazada<>();
    private Vendedor vendedor;

    public ControlarVendedor() {
        super(Vendedor.class);
    }

    public Vendedor getVendedor() {
        if (vendedor == null) {
            vendedor = new Vendedor();
        }
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

//8
    public ListaEnlazada<Vendedor> getVendedores() {
        if (vendedores.isEmpty()) {
            vendedores = listar();
        }
        return vendedores;
    }

    public void setVendedores(ListaEnlazada<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    public Boolean guardar() {
        this.vendedor.setId(generarId());
        return this.guardar(vendedor);
    }
    
         public Boolean update(Integer pos) throws IOException, VacioExcepcion, PositionException {
        return this.modificar(vendedor, pos);
    }
 public String generarCodigo(){
        StringBuilder codigo=new StringBuilder();
        Integer length=listar().getSize()+1;
        Integer pos=length.toString().length();
        for (int i = 0; i < (13-pos); i++) {
            codigo.append("0");
            
        }
        codigo.append(length.toString());
        return codigo.toString();
    }
//    public static void main(String[] args) {
//        ControlarVendedor mc = new ControlarVendedor();
//        mc.getVendedor().setId(1);
//        mc.getVendedor().setNombre(" Crrstian");
//        mc.getVendedor().setApellido("Ajila");
//        mc.getVendedor().setRuc("1234567890");
//        mc.getVendedor().setCedula("0994494004");
//        mc.guardar();
//        mc.setVendedor(null);
//
//    mc.getVendedor().setId(1);
//        mc.getVendedor().setNombre(" CRiss");
//        mc.getVendedor().setApellido("Ajila");
//        mc.getVendedor().setRuc("7854787568");
//        mc.getVendedor().setCedula("0994493645464");
//        mc.guardar();
//        mc.setVendedor(null);
//    }

}
