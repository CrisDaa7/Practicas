/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladorListas;

import controlador.listaEnlazada.ListaEnlazada;
import controlador.listaEnlazada.exepcion.PositionException;
import controlador.listaEnlazada.exepcion.VacioExcepcion;
import controladorListas.dao.AdaptadorDao;
import java.io.IOException;
import modeloListas.Auto;

/**
 *
 * @author cristian
 */
public class ControlarAuto extends AdaptadorDao<Auto>{
    
   
    private Auto auto;
    private ListaEnlazada<Auto> llantas=new ListaEnlazada<>();

    public ControlarAuto() {
        super(Auto.class);
    }

    public ListaEnlazada<Auto> getLlantas() {
        if(llantas.isEmpty())
            llantas=listar();
        return llantas;
    }

    public void setLlantas(ListaEnlazada<Auto> autos) {
        this.llantas = autos;
    }
    
      public Auto getAuto() {
        if(auto==null)
            auto=new Auto();
        return auto;
    }

    public void setAuto(Auto auto) {
        this.auto = auto;
    }

    public Boolean guardar(){
        auto.setId(generarId());
        return guardar(auto);
    }
    
      public Boolean update(Integer pos) throws IOException, VacioExcepcion, PositionException {
        return this.modificar(auto, pos);
    }
   
    public String generarCodigo(){
        StringBuilder codigo=new StringBuilder();
        Integer length=listar().getSize()+1;
        Integer pos=length.toString().length();
        for (int i = 0; i < (10-pos); i++) {
            codigo.append("0");
            
        }
        codigo.append(length.toString());
        return codigo.toString();
    }
}

